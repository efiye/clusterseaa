$(document).ready(function () {
    // $(".icofont-navigation-menu").click(function () {
    //     $(".main-menu").slideToggle(100);
    // })
    $(".icofont-navigation-menu").click(function () {
        $(".side-bar").addClass('active');
    })
    $(".icofont-ui-close").click(function () {
        $(".side-bar").removeClass('active');
    })
})